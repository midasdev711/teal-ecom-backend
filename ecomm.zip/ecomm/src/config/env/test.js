const env = {
  'mongo': {
    'host': 'mongodb://notes-mongo/test'
  }
}

module.exports = env;
