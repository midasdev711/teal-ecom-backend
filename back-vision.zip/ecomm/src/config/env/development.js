const env = {
  'mongo': {
    'host': 'mongodb://notes-mongo/development'
  }
}

module.exports = env;
