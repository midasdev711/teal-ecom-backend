const env = {
  'mongo': {
    'host': 'mongodb://staging-core-api.notesalong.com:27017/staging'
  }
}

module.exports = env;
