const env = {
  'mongo': {
    'host': 'mongodb://core-api.notesalong.com:27017/production'
  }
}

module.exports = env;
