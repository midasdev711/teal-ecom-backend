var constants = {
    'endpoint': {
        'sandbox': 'https://apitest.authorize.net/xml/v1/request.api',
        'production': 'https://api2.authorize.net/xml/v1/request.api'
    }
};

module.exports.constants = constants;